import * as React from "react"
import PeopleList from "./list3"

const OurPeople = (props) => (
  <PeopleList data={props.data} />
)

export default OurPeople
