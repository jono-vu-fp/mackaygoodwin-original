import { createContext } from 'react';
export const formDetailContext = createContext();
export const formHealthContext = createContext();
export const formEbookContext = createContext();